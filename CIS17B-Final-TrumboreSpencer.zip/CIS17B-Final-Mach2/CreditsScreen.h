/*

Credits are unfinished, will be done today

*/

#pragma once
#include "Texture.h"
#include "InputManager.h"

using namespace QuickSDL;

class CreditsScreen: public GameEntity
{
private:
	Texture texCredits;
	
	Texture texKristian;
	
	Texture texSpencer;

	Texture texWilliam;

	Texture duties[3][4];

	Texture texAcknowledgments;
	Texture texCarlBirch;
	Texture texAtherOmar;
};